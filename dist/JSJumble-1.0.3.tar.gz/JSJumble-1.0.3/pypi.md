# JSJumble
**Tool for obfuscating, compressing Javascript, and collecting static files.**  
### Check Github page for [Documentation](https://github.com/GoodDay360/JSJumble).